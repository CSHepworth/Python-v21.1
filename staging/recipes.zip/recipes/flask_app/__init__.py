from flask import Flask
app = Flask(__name__)
app.secret_key = "N0 F3DS 4LL0W3D"