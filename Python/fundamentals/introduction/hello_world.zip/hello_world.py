print("Hello World!")

name = "Cooper"
print("Hello", name, "!")
print("Hello " + name + "!")

numb = 39
print("Hello", numb, "!")
print("Hello " + str(numb) + "!")

fav_food1 = "Steak"
fav_food2 = "Green Thai Curry"

print("I love to eat {} and {}.".format(fav_food1, fav_food2))
print(f"I love to eat {fav_food1} and {fav_food2}.")